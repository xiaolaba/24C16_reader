EEPROM24C04_16
==============

EEPROM 24C04 / 24C16 library for Arduino - by Julien Le Sech

where it came from
==================
Forked from http://www.idreammicro.com/svn/idreammicro-arduino/trunk/libraries/Eeprom24C04_16

